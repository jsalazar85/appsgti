'use strict';

/**
 * Route configuration for the RDash module.
 */
angular.module('RDash').config(['$stateProvider', '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {

        // For unmatched routes
        $urlRouterProvider.otherwise('/tabmas');

        // Application routes
        $stateProvider
            .state('consulta', {
                url: '/consulta',
                views:{
                    '':{
                        templateUrl: 'templates/busqueda.view.html',
                        controller: 'busquedaCtrl'
                    }
                }
            })
            .state('carga', {
                url: '/carga',
                views:{
                    '':{
                        templateUrl: 'templates/tablero-carga-archivo-gen.view.html',
                        controller: 'tableroCargaArchivoGenCtrl'
                    }
                }
            })
            .state('testcomp', {
                url: '/testcomp',
                views:{
                    '':{
                        templateUrl: 'templates/detalle-servidores.view.html'
                    }
                }
            })
            /*
            .state('test', {
                url: '/test',
                views:{
                    '':{
                        templateUrl: 'templates/tablero-principal.view.html'
                    },
                    'resumen@test':{
                        templateUrl: 'templates/tablero-resumen.view.html',
                        controller:'tableroResumenViewCtrl'
                    }
                }
            })
            */
            .state('tablero', {
                url: '/tablero',
                views:{
                    '':{
                        templateUrl: 'templates/tablero-principal.view.html',
                        controller:'tableroPrincipalViewCtrl'
                    },
                    'resumen@tablero':{
                        templateUrl: 'templates/tablero-resumen.view.html',
                        controller:'tableroResumenViewCtrl'
                    },
                    'porArea@tablero':{
                        templateUrl: 'templates/tablero-area-negocio.view.html',
                        controller:'tableroAreaNegocioViewCtrl'
                    }
                }
            })
            .state('tableroMaster', {
                url: '/tabmas',
                views:{
                    '':{
                        templateUrl: 'templates/tablero-maestro.view.html',
                    },
                    'seccionPadron@tableroMaster':{
                        templateUrl: 'templates/seccion-padron.view.html',
                    },
                    'seccionAreas@tableroMaster':{
                        templateUrl: 'templates/seccion-areas.view.html',
                    },
                    'seccionIniciativas@tableroMaster':{
                        templateUrl: 'templates/seccion-iniciativas.view.html',
                    },
                    'seccionResumen@tableroMaster':{
                        templateUrl: 'templates/seccion-resumen.view.html',
                    },
                    'tableroCenso@tableroMaster':{
                        templateUrl: 'templates/tablero-censo.view.html',
                        controller: 'tableroCensoCtrl',
                    },
                    'tableroDictamen@tableroMaster':{
                        templateUrl: 'templates/tablero-dictamen.view.html',
                        controller: 'tableroDictamenCtrl',
                    },
                    'tableroAreaCartera@tableroMaster':{
                        templateUrl: 'templates/tablero-area-cartera.view.html',
                        controller: 'tableroAreaCarteraCtrl',
                    },
                    'tableroAreaRH@tableroMaster':{
                        templateUrl: 'templates/tablero-area-rh.view.html',
                        controller: 'tableroAreaRHCtrl',
                    },
                    'tableroAreaDel@tableroMaster':{
                        templateUrl: 'templates/tablero-area-del.view.html',
                        controller: 'tableroAreaDelCtrl',
                    },
                    'tableroAreaAtencion@tableroMaster':{
                        templateUrl: 'templates/tablero-area-atencion.view.html',
                        controller: 'tableroAtnSrvCtrl',
                    },
                    'tableroIniciativaMonto@tableroMaster':{
                        templateUrl: 'templates/tablero-iniciativa-rentas.view.html',
                        controller: 'tableroIniciativaCtrl'
                    },
                    'notaInformativa@tableroMaster':{
                        templateUrl: 'templates/nota-informativa.view.html'
                    }
                }
            })

    }
]).filter('percentFilter', function () {
    return function (value, scope) {
        var res="";
        if(angular.isDefined(value)){
            if(angular.isDefined(value.toFixed)){
                res=(value.toFixed(1)) +" %";
            }else{
                res=value+" %";
            }

        }
        return res;
    };
});;


